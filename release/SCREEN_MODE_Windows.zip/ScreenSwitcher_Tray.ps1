Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Import DDC switch logic
. "$scriptDir\SwitchInput.ps1"

# Create Tray Icon
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Icon = [System.Drawing.SystemIcons]::Application
$notifyIcon.Text = "Screen Switcher (Mac / Windows)"
$notifyIcon.Visible = $true

$contextMenu = New-Object System.Windows.Forms.ContextMenuStrip

$header = $contextMenu.Items.Add("MSI MAG401QR Switcher (155Hz)")
$header.Enabled = $false
$contextMenu.Items.Add("-") | Out-Null

# Mac no USB-C (27)
$itemMac = $contextMenu.Items.Add("🍎 Screen Mac (USB-C 155Hz)")
$itemMac.Add_Click({
    [MonitorManager]::SetInputSource(27)
})

# Windows no DisplayPort 1 (15)
$itemWin = $contextMenu.Items.Add("💻 Screen Windows (DisplayPort 155Hz)")
$itemWin.Add_Click({
    [MonitorManager]::SetInputSource(15)
})

$contextMenu.Items.Add("-") | Out-Null

$itemExit = $contextMenu.Items.Add("Sair")
$itemExit.Add_Click({
    $notifyIcon.Visible = $false
    [System.Windows.Forms.Application]::Exit()
})

$notifyIcon.ContextMenuStrip = $contextMenu

# Keep running
[System.Windows.Forms.Application]::Run()
